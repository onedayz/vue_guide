# vue_starter

### Introduce
This repository is front-end project based on Vue.js 

### Tech stack
1. Vue 3.0 (One Piece Release)
2. Vue-router 4.0.0(beta-9)
3. Scss 
4. webpack 4.x
5. vue-fontawesome 3.0.0-1

### How to run
> npm install<br>
> npm run serve
