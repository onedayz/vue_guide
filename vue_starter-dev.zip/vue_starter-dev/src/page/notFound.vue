<template>
    <div class="not-found">
        <h1>404 Not Found</h1>
    </div>
</template>

<script>
export default {
    name: 'notFound'
}
</script>

<style scoped lang="scss">
.not-found{
    display: flex; justify-content: center; align-items: center;
    background-color: $color__indigo-500; color: $color__white;
}
</style>