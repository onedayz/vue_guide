<template>
    <div class="front-end-page">
        <h3>Front End Page</h3>
    </div>
</template>

<script>
export default {
    name: 'frontEnd'
}
</script>