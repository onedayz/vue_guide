<template>
    <div class="content">
        <h2>Content Area</h2>
    </div>
</template>

<script>
export default {
    name: 'content'
}
</script>

<style scoped lang="scss">

</style>