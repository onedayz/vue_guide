<template>
    <div class="back-end-page">
        <h3>Back End Page</h3>
    </div>
</template>

<script>
export default {
    name: 'backEnd'
}
</script>