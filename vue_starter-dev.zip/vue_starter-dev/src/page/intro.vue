<template>
    <div class="intro-page">
        <h3>Intro</h3>
    </div>
</template>

<script>
export default {
    name: 'intro',
}
</script>
